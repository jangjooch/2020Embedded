﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0721_HW_Class01.Model
{
    class Fan_v2:Fan_v1
    {
        public string remote;
        public ConnectTimer connectTimer;
    }
}
